# Meter Reading Cleaner

This Streamlit app lets you upload water or electricity meter readings, clean the data, and download a tidy Excel file.

**Features:**
- Keeps the highest reading per flat
- Fills in missing flats
- Rounds and cleans data
- Exports to Excel
